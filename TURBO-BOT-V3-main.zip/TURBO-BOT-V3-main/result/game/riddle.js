[
  { "author" : "TURBO",
    "index": 1,
    "soal": " Animales como las lagartijas que pueden cambiar el color de su piel?",
    "jawaban": "Camaleón"
  },
  { "author" : "TURBO",
    "index": 2,
    "soal": " Este banco está ocupado por un padre y por un hijo: El padre se llama Juan y el hijo ya te lo he dicho",
    "jawaban": "Esteban"
  },
  { "author" : "TURBO",
    "index": 3,
    "soal": " Algunos meses tienen 31 días, otros solo 30.¿Cuantos tienen 28 días?",
    "jawaban": "Todos"
  },
  { "author" : "TURBO",
    "index": 4,
    "soal": " En el cielo brinco y vuelo. Me encanta subir, flotar y lucir mi pelo.",
    "jawaban": "Cometa"
  },
  { "author" : "TURBO",
    "index": 5,
    "soal": " Carrera de larga distancia 42,195 km?",
    "jawaban": "Maraton"
  },
  { "author" : "TURBO",
    "index": 6,
    "soal": " La línea que divide la Tierra en los hemisferios norte y sur?",
    "jawaban": "Ecuador"
  },
  { "author" : "TURBO",
    "index": 7,
    "soal": " Somos muchos hermanitos, en una sola casa vivimos, si nos rascan la cabeza al instante morimos",
    "jawaban": "Fósforos"
  },
  { "author" : "TURBO",
    "index": 8,
    "soal": "¿Cómo se llama la fuerza de atracción que se produce en el universo, incluida la Tierra?",
    "jawaban": "Gravedad"
  },
  { "author" : "TURBO",
    "index": 9,
    "soal": " ¿El nombre de la película que cuenta la historia de un robot que puede convertirse en vehículo?",
    "jawaban": "Transformers"
  },
  { "author" : "TURBO",
    "index": 10,
    "soal": " ¿Un luchador en la Antigua Roma que luchó por el entretenimiento público?",
    "jawaban": "Gladiador"
  },
  { "author" : "TURBO",
    "index": 11,
    "soal": " ¿El nombre del lujoso barco de pasajeros que se hundió durante su viaje inaugural en 1912?",
    "jawaban": "Titanic"
  },
  { "author" : "TURBO",
    "index": 12,
    "soal": " ¿El club de fútbol de Italia que tiene el sobrenombre de Old Lady?,
    "jawaban": "Juventus"
  },
  { "author" : "TURBO",
    "index": 13,
    "soal": " ¿El mecanismo del sistema de gobierno estatal basado en la voluntad del pueblo?",
    "jawaban": "Democracia"
  },
  { "author" : "TURBO",
    "index": 14,
    "soal": " Es la frustración vertical de un deseo horizontal",
    "jawaban": "Bailar"
  },
  { "author" : "TURBO",
    "index": 15,
    "soal": " ¿Cuál es el nombre de la moneda utilizada en Rusia?",
    "jawaban": "Rublo"
  },
  { "author" : "TURBO",
    "index": 16,
    "soal": " ¿Ciencias naturales que observan cuerpos celestes y fenómenos fuera de la atmósfera terrestre?",
    "jawaban": "Astronomía"
  },
  { "author" : "TURBO",
    "index": 17,
    "soal": " ¿El emperador francés que gobernó Europa en 1803-1815?",
    "jawaban": "Napoleon"
  },
  { "author" : "TURBO",
    "index": 18,
    "soal": " ¿Artista español de fama mundial con un género artístico llamado cubismo?",
    "jawaban": "Picasso"
  },
  { "author" : "TURBO",
    "index": 19,
    "soal": " ¿El nombre del comandante en jefe de las Fuerzas Aliadas en la Segunda Guerra Mundial?",
    "jawaban": "Eisenhower"
  },
  { "author" : "TURBO",
    "index": 20,
    "soal": " ¿Un arma ficticia en el mundo de Star Wars, utilizada por los Jedi y los Sith?",
    "jawaban": "Sabledeluz"
  },
  { "author" : "TURBO",
    "index": 21,
    "soal": " ¿El nombre de la península en Europa donde se encuentran los países de Noruega y Suecia?",
    "jawaban": "Skandinavia"
  },
  { "author" : "TURBO",
    "index": 22,
    "soal": " ¿El estadio de fútbol de Londres que también es la sede del Arsenal FC?",
    "jawaban": "Emirates"
  },
  { "author" : "TURBO",
    "index": 23,
    "soal": " Cantante mundialmente famosa, ¿solía estar en el grupo Destiny's Child?",
    "jawaban": "Beyonce"
  },
  { "author" : "TURBO",
    "index": 24,
    "soal": " ¿El término para la creencia de que Dios es uno o uno?",
    "jawaban": "Monoteismo"
  },
  { "author" : "TURBO",
    "index": 25,
    "soal": " ¿El nombre del reino donde el rey es actualmente vicegobernador de DI Yogyakarta?",
    "jawaban": "Pakualaman"
  },
  { "author" : "TURBO",
    "index": 26,
    "soal": " ¿Llamado uno de los más grandes matemáticos de la historia, nacido en el 287 a. C.?",
    "jawaban": "Archimedes"
  },
  { "author" : "TURBO",
    "index": 27,
    "soal": " ¿La cadena montañosa más alta de Indonesia, ubicada en la isla de Papúa?",
    "jawaban": "Jayawijaya"
  },
  { "author" : "TURBO",
    "index": 28,
    "soal": " ¿Un grupo de superhéroes de ficción formado por Iron Man, Capitán América, Hulk, Thor?",
    "jawaban": "Vengadores"
  },
  { "author" : "TURBO",
    "index": 29,
    "soal": " ¿El nombre de un vasto territorio en Rusia, que cubre casi todo el territorio del norte de Asia?",
    "jawaban": "Siberia"
  },
  { "author" : "TURBO",
    "index": 30,
    "soal": " ¿Un objeto o medio que conduce corriente eléctrica con facilidad?",
    "jawaban": "Conductor"
  },
  { "author" : "TURBO",
    "index": 31,
    "soal": " ¿El nombre del idioma que se habla en Irán, Tayikistán, Afganistán y Uzbekistán?",
    "jawaban": "Farsi"
  },
  { "author" : "TURBO",
    "index": 32,
    "soal": " ¿El área donde hubo la primera práctica agrícola alrededor del 8000 aC?",
    "jawaban": "Mesopotamia"
  },
  { "author" : "TURBO",
    "index": 33,
    "soal": " ¿Una ideología basada en el principio de liderazgo con autoridad absoluta?",
    "jawaban": "Fascismo"
  },
  { "author" : "TURBO",
    "index": 34,
    "soal": " ¿El nombre del período geológico de hace 252 a 66 millones de años, también llamado Edad de los Reptiles?",
    "jawaban": "Mesozoico"
  },
  { "author" : "TURBO",
    "index": 35,
    "soal": " El nombre conocido en la leyenda ¿Respuesta como el arquitecto que diseñó el templo de Borobudur?",
    "jawaban": "Gunadharma"
  },
  { "author" : "TURBO",
    "index": 36,
    "soal": " Una danza tradicional china que usa un disfraz que se asemeja a un león.",
    "jawaban": "Danza del leon"
  },
  { "author" : "TURBO",
    "index": 37,
    "soal": " ¿Qué término significa el movimiento de personas de las aldeas a las ciudades?",
    "jawaban": "Urbanización"
  },
  { "author" : "TURBO",
    "index": 38,
    "soal": " Famoso grupo de música de la década de 1970 de Bandung, ¿el personal son tres hermanos?",
    "jawaban": "Bimbo"
  },
  { "author" : "TURBO",
    "index": 39,
    "soal": " Ni torcida ni inclinada tiene que estar la pared, para eso tengo plomada y me ayudo del nivel.",
    "jawaban": "Albañil"
  },
  { "author" : "TURBO",
    "index": 40,
    "soal": " ¿Conocido como el “maestro keroncong indonesio”, el creador de la canción Bengawan Solo?",
    "jawaban": "Gesang"
  },
  { "author" : "TURBO",
    "index": 41,
    "soal": " ¿La escala de temperatura donde el punto de congelación del agua está en 0 grados y el punto de ebullición está en 100 grados?",
    "jawaban": "Celsius"
  },
  { "author" : "TURBO",
    "index": 42,
    "soal": " ¿Espíritus míticos javaneses, en forma de humanos parecidos a simios, grandes y peludos?",
    "jawaban": "Génerouwo"
  },
  { "author" : "TURBO",
    "index": 43,
    "soal": " ¿Un distrito de Los Ángeles conocido por su industria cinematográfica mundial?",
    "jawaban": "Hollywood"
  },
  { "author" : "TURBO",
    "index": 44,
    "soal": " ¿La rama de la biología que estudia la herencia de rasgos en organismos y suborganismos?",
    "jawaban": "Genética"
  },
  { "author" : "TURBO",
    "index": 45,
    "soal": " Un antiguo sitio humano en Java Central, ¿también es Patrimonio de la Humanidad por la UNESCO?",
    "jawaban": "Sangiran"
  },
  { "author" : "TURBO",
    "index": 46,
    "soal": " ¿Una roca más pequeña que un planeta en órbita alrededor del Sol?",
    "jawaban": "Asteroides"
  },
  { "author" : "TURBO",
    "index": 47,
    "soal": " ¿El término para animales o plantas herbívoros?",
    "jawaban": "Herbívoro"
  },
  { "author" : "TURBO",
    "index": 48,
    "soal": " ¿Un término que significa masacre sistemática de una tribu o grupo?",
    "jawaban": "Genocidio"
  },
  { "author" : "TURBO",
    "index": 49,
    "soal": " ¿Cómo se llama la enfermedad febril transmitida por la hembra del mosquito Anopheles?",
    "jawaban": "Malaria"
  },
  { "author" : "TURBO",
    "index": 50,
    "soal": " ¿El nombre de un personaje de ficción cultural de Sundanese que es divertido, inocente, pero al mismo tiempo inteligente?",
    "jawaban": "Kabayan"
  },
  { "author" : "TURBO",
    "index": 51,
    "soal": " ¿El dormitorio donde estudian los estudiantes santri bajo la guía del Kiai?",
    "jawaban": "Internado"
  },
  { "author" : "TURBO",
    "index": 52,
    "soal": " ¿Compañía japonesa de videojuegos, creadora de Mario Bros. y Pokémon?",
    "jawaban": "Nintendo"
  },
  { "author" : "TURBO",
    "index": 53,
    "soal": " ¿Una religión oficial en Indonesia basada en las enseñanzas de Confucio?",
    "jawaban": "Khong hu cu"
  },
  { "author" : "TURBO",
    "index": 54,
    "soal": " ¿El nombre de una enciclopedia en línea que cualquiera puede escribir y editar gratis?",
    "jawaban": "Wikipedia"
  },
  { "author" : "TURBO",
    "index": 55,
    "soal": " ¿Formar un cuadrilátero, un par de lados paralelos pero no de la misma longitud?",
    "jawaban": "Trapezoide"
  },
  { "author" : "TURBO",
    "index": 56,
    "soal": " ¿Enfermedades en las que la hormona reguladora del azúcar en sangre del cuerpo no es suficiente?",
    "jawaban": "Diabetes"
  },
  { "author" : "TURBO",
    "index": 57,
    "soal": " ¿El país independiente más pequeño del mundo reconocido internacionalmente?",
    "jawaban": "Vaticano"
  },
  { "author" : "TURBO",
    "index": 58,
    "soal": " ¿Un antiguo imperio en territorio griego gobernado por Alejandro Magno?",
    "jawaban": "Macedónio"
  },
  { "author" : "TURBO",
    "index": 59,
    "soal": " ¿El país con la segunda población más musulmana del mundo?",
    "jawaban": "Pakistan"
  },
  { "author" : "TURBO",
    "index": 60,
    "soal": " ¿Síntomas de función cerebral disminuida, generalmente ocurre en ancianos?",
    "jawaban": "Demencia"
  },
  { "author" : "TURBO",
    "index": 61,
    "soal": " ¿Combustible fósil, utilizado en plantas de energía de vapor?",
    "jawaban": "Carbón"
  },
  { "author" : "TURBO",
    "index": 62,
    "soal": " ¿El nombre del famoso templo de Bali que se construyó en la punta de una roca?",
    "jawaban": "Uluwatu"
  },
  { "author" : "TURBO",
    "index": 63,
    "soal": " ¿Un título obtenido por el hijo del sultán Agung de Mataram?",
    "jawaban": "Preciso"
  },
  { "author" : "TURBO",
    "index": 64,
    "soal": " ¿Una persona encargada de cuidar a bebés o niños en una familia?",
    "jawaban": "azafata"
  },
  { "author" : "TURBO",
    "index": 65,
    "soal": " D¿El área de Japón donde ocurrió la fuga nuclear en 2011?",
    "jawaban": "Fukushima"
  },
  { "author" : "TURBO",
    "index": 66,
    "soal": " ¿Protección financiera para la vida, la salud, la propiedad, etc.?",
    "jawaban": "Seguro"
  },
  { "author" : "TURBO",
    "index": 67,
    "soal": " P¿La empresa italiana del logotipo del caballo es un fabricante de supercoches y coches de carreras?",
    "jawaban": "Ferrari"
  },
  { "author" : "TURBO",
    "index": 68,
    "soal": " ¿Una tribu del sur de Sulawesi que es famosa por ser un marinero consumado?",
    "jawaban": "BugisVampir yang"
  },
  { "author" : "TURBO",
    "index": 69,
    "soal": " ¿El vampiro que es el personaje principal de la ficción de Bram Stoker?",
    "jawaban": "Drácula"
  },
  { "author" : "TURBO",
    "index": 70,
    "soal": " ¿Este planeta es el planeta más grande del Sistema Solar?",
    "jawaban": "Júpiter"
  },
  { "author" : "TURBO",
    "index": 71,
    "soal": " ¿Qué plantas se usaban para fabricar papel en el Antiguo Egipto?",
    "jawaban": "Papiro"
  },
  { "author" : "TURBO",
    "index": 72,
    "soal": " ¿Explosivos en forma de una mezcla en polvo de azufre, carbón vegetal y nitrato de potasio?",
    "jawaban": "Pólvora"
  },
  { "author" : "TURBO",
    "index": 73,
    "soal": " ¿El idioma oficial que también se habla ampliamente en Filipinas?",
    "jawaban": "Tagalo"
  },
  { "author" : "TURBO",
    "index": 74,
    "soal": " Un pequeño país de América del Sur, ¿hay muchos descendientes de Java?",
    "jawaban": "Surinam"
  },
  { "author" : "TURBO",
    "index": 75,
    "soal": " ¿El semental alado de la mitología griega?",
    "jawaban": "Pegaso"
  },
  { "author" : "TURBO",
    "index": 76,
    "soal": " Banda de rock alternativo de Londres. vocalista llamado Chris Martin?",
    "jawaban": "Coldplay"
  },
  { "author" : "TURBO",
    "index": 77,
    "soal": " ¿Qué fruta cortada tiene una sección transversal en forma de estrella?",
    "jawaban": "Fruta estrella"
  },
  { "author" : "TURBO",
    "index": 78,
    "soal": " ¿Un conjunto musical que suele contar con metalófonos, xilófonos, tambores y gongs?",
    "jawaban": "Gamelan"
  },
  { "author" : "TURBO",
    "index": 79,
    "soal": " ¿El nombre de la ciudad por la que durante varios siglos se debatió el islam, el cristianismo, el judaísmo?",
    "jawaban": "Jerusalén"
  },
  { "author" : "TURBO",
    "index": 80,
    "soal": " ¿El idioma oficial de Bangladesh, hablado por unos 200 millones de personas?",
    "jawaban": "Bengali"
  },
  { "author" : "TURBO",
    "index": 81,
    "soal": " ¿Una bebida embriagadora hecha de etanol?",
    "jawaban": "Alcohol"
  },
  { "author" : "TURBO",
    "index": 82,
    "soal": " ¿El único volcán activo en Europa continental se encuentra en Italia?",
    "jawaban": "Vesubio"
  },
  { "author" : "TURBO",
    "index": 83,
    "soal": " ¿Un personaje de ficción con el pelo muy largo, el protagonista principal de la película animada Enredados?",
    "jawaban": "Rapunzel"
  },
  { "author" : "TURBO",
    "index": 84,
    "soal": " ¿Desastres naturales en forma de grandes olas del mar?",
    "jawaban": "Tsunami"
  },
  { "author" : "TURBO",
    "index": 85,
    "soal": " ¿El nombre de la ciudad en el antiguo estado turco llamado Constantinopla?",
    "jawaban": "Estanbul"
  },
  { "author" : "TURBO",
    "index": 86,
    "soal": " ¿La subespecie humana que se extinguió de la faz de la tierra hace unos 30.000 años?",
    "jawaban": "Neandertales"
  },
  { "author" : "TURBO",
    "index": 87,
    "soal": " ¿El nombre del ritual de suicidio de los samuráis en Japón al desgarrar el estómago?",
    "jawaban": "Seppuku"
  },
  { "author" : "TURBO",
    "index": 88,
    "soal": " ¿El tipo de queso de Italia que se encuentra a menudo en los platos de pizza?",
    "jawaban": "Queso Mozzarella"
  },
  { "author" : "TURBO",
    "index": 89,
    "soal": " ¿Título para la esposa de un monarca (rey, sultán o emperador)?",
    "jawaban": "Emperatriz"
  },
  { "author" : "TURBO",
    "index": 90,
    "soal": " ¿El nombre de la tribu que ha habitado durante mucho tiempo el Polo Norte de la Tierra?",
    "jawaban": "esquimal"
  },
  { "author" : "TURBO",
    "index": 91,
    "soal": " ¿El segundo elemento más abundante después del oxígeno en el cuerpo humano?",
    "jawaban": "Carbón"
  },
  { "author" : "TURBO",
    "index": 92,
    "soal": " ¿El genocidio contra los judíos europeos durante la Segunda Guerra Mundial?",
    "jawaban": "Holocausto"
  },
  { "author" : "TURBO",
    "index": 93,
    "soal": " ¿Cuál es el proceso de conversión de azúcar en etanol mediante levadura?",
    "jawaban": "Fermentación"
  },
  { "author" : "TURBO",
    "index": 94,
    "soal": " ¿Adivinación en la tradición javanesa que discute la existencia de una reina justa?",
    "jawaban": "Jayabaya"
  },
  { "author" : "TURBO",
    "index": 95,
    "soal": " ¿Figura polaca del siglo XV que acuñó la teoría del heliocentrismo?",
    "jawaban": "Copérnico"
  },
  { "author" : "TURBO",
    "index": 96,
    "soal": " ¿Una herramienta popular para unir dos lados de la tela, utilizada en ropa, bolsos, etc.?",
    "jawaban": "Cremallera"
  },
  { "author" : "TURBO",
    "index": 97,
    "soal": " ¿La unidad de diferencia de potencial eléctrico entre dos puntos en un circuito eléctrico?",
    "jawaban": "Voltaje"
  },
  { "author" : "TURBO",
    "index": 98,
    "soal": " ¿Un sistema social que le dio un gran poder a la nobleza?",
    "jawaban": "Feudalismo"
  },
  { "author" : "TURBO",
    "index": 99,
    "soal": " ¿El nombre del edulcorante artificial / sintético que se compone de dos tipos de aminoácidos?",
    "jawaban": "Aspartamo"
  },
  { "author" : "TURBO",
    "index": 100,
    "soal": " ¿La primera consola de videojuegos producida por Sony en la década de 1990?",
    "jawaban": "PlayStation"
  },
  { "author" : "TURBO",
    "index": 101,
    "soal": " ¿Otro nombre para la isla de Borneo, usado durante el reinado de las Indias Orientales Holandesas?",
    "jawaban": "Borneo"
  },
  { "author" : "TURBO",
    "index": 102,
    "soal": " ¿Una piedra preciosa o piedra preciosa cuyo color está en el rango verde?",
    "jawaban": "Esmeralda"
  },
  { "author" : "TURBO",
    "index": 103,
    "soal": " ¿El nombre del museo de historia y cultura javanesa en Yogyakarta?",
    "jawaban": "Sonobudoyo"
  },
  { "author" : "TURBO",
    "index": 104,
    "soal": " ¿La rama de la ciencia médica que estudia aspectos de la salud del cuerpo y el alma humanos?",
    "jawaban": "Psiquiatría"
  },
  { "author" : "TURBO",
    "index": 105,
    "soal": " ¿El primer presidente de Estados Unidos, también el nombre de la capital de Estados Unidos?",
    "jawaban": "Washingthon"
  },
  { "author" : "TURBO",
    "index": 106,
    "soal": " ¿El único tipo de mamífero que puede volar?",
    "jawaban": "Murciélago"
  },
  { "author" : "TURBO",
    "index": 107,
    "soal": " Archipiélago de Oceanía, formado por más de 1000 islas?",
    "jawaban": "Polinesia"
  },
  { "author" : "TURBO",
    "index": 108,
    "soal": " El título del monarca de la era del reino, ¿el nivel es equivalente al emperador?",
    "jawaban": "Maharaja"
  },
  { "author" : "TURBO",
    "index": 109,
    "soal": " ¿El nombre de la isla más cercana a Singapur?",
    "jawaban": "Batam"
  },
  { "author" : "TURBO",
    "index": 110,
    "soal": " ¿Rama de las fuerzas armadas capaz de realizar incursiones anfibias?",
    "jawaban": "Infantería de marina"
  },
  { "author" : "TURBO",
    "index": 111,
    "soal": " ¿La empresa operadora de telefonía celular en Indonesia con más suscriptores?",
    "jawaban": "Telkomsel"
  },
  { "author" : "TURBO",
    "index": 112,
    "soal": " ¿Cómo se llama el animal con caparazón de 10 patas?",
    "jawaban": "Cangrejo"
  },
  { "author" : "TURBO",
    "index": 113,
    "soal": " ¿Objetos en miniatura para representar una escena o una escena?",
    "jawaban": "Diorama"
  },
  { "author" : "TURBO",
    "index": 114,
    "soal": " Casa tradicional de Toraja, el techo es curvo como un barco?",
    "jawaban": "Tonkonan"
  },
  { "author" : "TURBO",
    "index": 115,
    "soal": " ¿La cueva que se convirtió en la sede del príncipe Diponegoro en 1825?",
    "jawaban": "Selarong"
  },
  { "author" : "TURBO",
    "index": 116,
    "soal": " ¿El nombre de una criatura en forma de mujer que vive en el cielo?",
    "jawaban": "Ángel"
  },
  { "author" : "TURBO",
    "index": 117,
    "soal": " ¿La espada curva de un solo filo que usaba el samurái japonés?",
    "jawaban": "Katana"
  },
  { "author" : "TURBO",
    "index": 118,
    "soal": " ¿Material de joyería producido en el tejido blando de un animal molusco?",
    "jawaban": "Perla"
  },
  { "author" : "TURBO",
    "index": 119,
    "soal": " ¿El nombre de la empresa del desarrollador de juegos finlandés Clash of Clans?",
    "jawaban": "Supercell"
  },
  { "author" : "TURBO",
    "index": 120,
    "soal": " ¿Una bebida tradicional de Sundan, hecha de azúcar de palma y leche de coco?",
    "jawaban": "Bajigur"
  },
  { "author" : "TURBO",
    "index": 121,
    "soal": " ¿El género musical que se desarrolló originalmente en Jamaica en la década de 1960?",
    "jawaban": "Reggae"
  },
  { "author" : "TURBO",
    "index": 122,
    "soal": " Drama tradicional de Java Oriental, ¿es entretenido y te hace reír?",
    "jawaban": "Ludruk"
  },
  { "author" : "TURBO",
    "index": 123,
    "soal": " ¿El nombre del dormitorio de la escuela ficticia donde los personajes de Harry Potter estudian magia??",
    "jawaban": "Hogwarts"
  },
  { "author" : "TURBO",
    "index": 124,
    "soal": " ¿La ciudad cuyo nombre proviene de su historia como fabricante de terasi?",
    "jawaban": "Cirebon"
  },
  { "author" : "TURBO",
    "index": 125,
    "soal": " ¿Un funcionario público en el ámbito jurídico que esté autorizado para realizar una escritura pública?",
    "jawaban": "Notario público"
  },
  { "author" : "TURBO",
    "index": 126,
    "soal": " ¿Qué tipo de azúcar procesa el cuerpo humano a partir de los carbohidratos?",
    "jawaban": "Glucosa"
  },
  { "author" : "TURBO",
    "index": 127,
    "soal": " ¿Un pequeño cuchillo de mano con una forma curva típica del sudeste asiático?",
    "jawaban": "Kerambit"
  },
  { "author" : "TURBO",
    "index": 128,
    "soal": " ¿Una antigua especie de elefante del género mamut, que comía hojas y ramas de árboles?",
    "jawaban": "Mastodonte"
  },
  { "author" : "TURBO",
    "index": 129,
    "soal": " ¿El juramento hecho por Gajah Mada en la ceremonia de su nombramiento como Patih?",
    "jawaban": "Palapa"
  },
  { "author" : "TURBO",
    "index": 130,
    "soal": " ¿Depositar productos en el banco, los retiros solo se pueden hacer en determinados momentos?",
    "jawaban": "Depositar"
  },
  { "author" : "TURBO",
    "index": 131,
    "soal": " ¿Fenómenos ópticos y meteorológicos en forma de luz multicolor que aparece en el cielo?",
    "jawaban": "Arcoíris"
  },
  { "author" : "TURBO",
    "index": 132,
    "soal": " ¿Armas de cohetes militares que tienen un sistema de control automático para encontrar objetivos?",
    "jawaban": "Misil"
  },
  { "author" : "TURBO",
    "index": 133,
    "soal": " ¿Sindicatos del crimen organizado en Japón que tienen sus propias formas y leyes?",
    "jawaban": "Yakuza"
  },
  { "author" : "TURBO",
    "index": 134,
    "soal": " ¿La clase intelectual que también es un grupo de trabajo o de color en el hinduismo?",
    "jawaban": "Brahmán"
  },
  { "author" : "TURBO",
    "index": 135,
    "soal": " ¿La estación seca en los trópicos influenciada por el sistema monzónico?",
    "jawaban": "sequía"
  },
  { "author" : "TURBO",
    "index": 136,
    "soal": " ¿Escuelas públicas cuyo plan de estudios contiene lecciones islámicas?",
    "jawaban": "Madrasa"
  },
  { "author" : "TURBO",
    "index": 137,
    "soal": " ¿Las plantas que pueden crecer sin agua durante mucho tiempo, existen en áreas desérticas?",
    "jawaban": "Cactus"
  },
  { "author" : "TURBO",
    "index": 138,
    "soal": " ¿Una orden de mamíferos de cinco dedos, incluidos lémures, simios y humanos?",
    "jawaban": "primates"
  },
  { "author" : "TURBO",
    "index": 139,
    "soal": " ¿Blusa tradicional de mujer hecha de material fino, usada con un pareo o batik?",
    "jawaban": "Kebaya"
  },
  { "author" : "TURBO",
    "index": 140,
    "soal": " Tipos de proteína que normalmente se encuentra en el trigo, ¿los celíacos evitan?",
    "jawaban": "Gluten"
  },
  { "author" : "TURBO",
    "index": 141,
    "soal": " ¿Un deporte marcial desarrollado por africanos en Brasil en el siglo XVI?",
    "jawaban": "Capoeira"
  },
  { "author" : "TURBO",
    "index": 142,
    "soal": " ¿La erosión de sólidos como rocas / suelo debido al transporte de viento, agua o hielo?",
    "jawaban": "Erosión"
  },
  { "author" : "TURBO",
    "index": 143,
    "soal": " El pescado, que es un pariente cercano del atún, a menudo se procesa en galletas saladas, albóndigas, pempek.",
    "jawaban": "Caballa"
  },
  { "author" : "TURBO",
    "index": 144,
    "soal": " ¿Un tipo de baile social tradicional de Sundan, especialmente en el área de Karawang?",
    "jawaban": "Jaipongan"
  },
  { "author" : "TURBO",
    "index": 145,
    "soal": " ¿Sistema numérico en el que los números se escriben con dos símbolos, 0 y 1?",
    "jawaban": "Binario"
  },
  { "author" : "TURBO",
    "index": 146,
    "soal": " Especia de las semillas de la familia del jengibre, ¿es la tercera especia más cara del mundo?",
    "jawaban": "Cardamomo"
  },
  { "author" : "TURBO",
    "index": 147,
    "soal": " ¿El continente que cubre el Polo Sur de la Tierra tiene una temperatura muy baja?",
    "jawaban": "Antártida"
  },
  { "author" : "TURBO",
    "index": 148,
    "soal": " ¿El arma arrojadiza que fue ampliamente utilizada en la Edad Media para destruir muros?",
    "jawaban": "Trebuchet"
  },
  { "author" : "TURBO",
    "index": 149,
    "soal": " ¿Copos blancos que son exfoliación excesiva de piel muerta en la cabeza?",
    "jawaban": "Caspa"
  },
  { "author" : "TURBO",
    "index": 150,
    "soal": " ¿La ciencia que estudia el lenguaje en manuscritos antiguos?",
    "jawaban": "Filología"
  },
  { "author" : "TURBO",
    "index": 151,
    "soal": " ¿Leche que solo se produce en las últimas etapas del embarazo unos días después del parto?",
    "jawaban": "Calostro"
  },
  { "author" : "TURBO",
    "index": 152,
    "soal": " ¿Una planta originaria de Japón tiene un sabor fuerte / picante que se come como saborizante en la cocina japonesa?",
    "jawaban": "Wasabi"
  },
  { "author" : "TURBO",
    "index": 153,
    "soal": " ¿Un deporte que usa un bate, el campo es cuadrado?",
    "jawaban": "Béisbol"
  },
  { "author" : "TURBO",
    "index": 154,
    "soal": " ¿Una especia típica de la cocina Toba Batak, también conocida como pimienta Batak?",
    "jawaban": "Andaliman"
  },
  { "author" : "TURBO",
    "index": 155,
    "soal": " ¿El sistema de gobierno adoptado por el Reino Unido, Japón, los Países Bajos, Malasia, Singapur?",
    "jawaban": "parlamentario"
  },
  { "author" : "TURBO",
    "index": 156,
    "soal": " ¿Comida tradicional coreana en forma de verduras fermentadas en escabeche con condimentos picantes?",
    "jawaban": "Kimchi"
  },
  { "author" : "TURBO",
    "index": 157,
    "soal": " ¿El término para algo que tiene propósitos sociales o ambientales, no una ganancia material?",
    "jawaban": "Sin ánimo de lucro"
  },
  { "author" : "TURBO",
    "index": 158,
    "soal": " ¿Un movimiento que lucha por la igualdad de las mujeres en política, economía, cultura, etc.?",
    "jawaban": "Feminismo"
  },
  { "author" : "TURBO",
    "index": 159,
    "soal": " ¿Un té fermentado y una bebida azucarada del este de Asia?",
    "jawaban": "Kombucha"
  },
  { "author" : "TURBO",
    "index": 160,
    "soal": " ¿Los partidarios de la línea dura de Rusia en 1903 que piensan que el cambio debe ganarse con armas?",
    "jawaban": "Bolchevique"
  },
  { "author" : "TURBO",
    "index": 161,
    "soal": " ¿El nombre de la isla volcánica en medio del lago Toba, en el norte de Sumatra?",
    "jawaban": "Samosir"
  },
  { "author" : "TURBO",
    "index": 162,
    "soal": " ¿Soldados en la antigua Grecia, funcionando como lanceros en una formación de falange?",
    "jawaban": "Hoplitas"
  },
  { "author" : "TURBO",
    "index": 163,
    "soal": " ¿El nombre de una semana que consta de 5 días en la cultura javanesa y balinesa?",
    "jawaban": "Pancawara"
  },
  { "author" : "TURBO",
    "index": 164,
    "soal": " ¿Cómo servir comida durante el período colonial holandés con una variedad de platos indonesios?",
    "jawaban": "Rijsttafel"
  },
  { "author" : "TURBO",
    "index": 165,
    "soal": " ¿El término para el cultivo con agua sin usar suelo?",
    "jawaban": "Hidroponia"
  },
  { "author" : "TURBO",
    "index": 166,
    "soal": " El metal más abundante en la Tierra, ¿es el mejor conductor de electricidad?",
    "jawaban": "Aluminio"
  },
  { "author" : "TURBO",
    "index": 167,
    "soal": " ¿Una organización económica basada en la economía de las personas y el principio de parentesco?",
    "jawaban": "Cooperativa"
  },
  { "author" : "TURBO",
    "index": 168,
    "soal": " ¿Fiestas hindúes, celebradas cada 210 días utilizando cálculos del calendario balinés?",
    "jawaban": "Galungan"
  },
  { "author" : "TURBO",
    "index": 169,
    "soal": "¿La ciencia que estudia la forma de la superficie terrestre así como la superficie de los planetas, satélites naturales, asteroides?",
    "jawaban": "Topografía"
  },
  { "author" : "TURBO",
    "index": 170,
    "soal": " ¿Ofrendas a dioses o espíritus ancestrales por parte de seguidores de creencias antiguas en Indonesia?",
    "jawaban": "ofrendas"
  },
  { "author" : "TURBO",
    "index": 171,
    "soal": " JEl título de la canción popular coreana, así como el símbolo de Corea, ¿se conoce en Corea del Norte y del Sur?",
    "jawaban": "Arirang"
  },
  { "author" : "TURBO",
    "index": 172,
    "soal": " ¿El término forma de pueblo nómada que elige vivir una vida nómada para sobrevivir?",
    "jawaban": "Nómada"
  },
  { "author" : "TURBO",
    "index": 173,
    "soal": " ¿Un tipo raro de hongo de pino que es un ingrediente alimenticio de lujo caro en Japón?",
    "jawaban": "Matsutake"
  },
  { "author" : "TURBO",
    "index": 174,
    "soal": " Una costumbre comunitaria que regula el flujo de la descendencia proviene del lado materno",
    "jawaban": "Matrilineal"
  },
  { "author" : "TURBO",
    "index": 175,
    "soal": " ¿Un prado lleno de arbustos y algún tipo de árbol que crece extendido?",
    "jawaban": "Sabana"
  },
  { "author" : "TURBO",
    "index": 176,
    "soal": " ¿El explorador italiano que descubrió América en 1492?",
    "jawaban": "Capoeira"
  },
  { "author" : "TURBO",
    "index": 177,
    "soal": " ¿La puntuación o escala utilizada para evaluar el estado de salud del recién nacido?",
    "jawaban": "Apgar"
  },
  { "author" : "TURBO",
    "index": 178,
    "soal": " ¿Una de las islas del norte de Sulawesi que tiene la mayor biodiversidad marina del mundo?",
    "jawaban": "Bunaken"
  },
  { "author" : "TURBO",
    "index": 179,
    "soal": " ¿Experto en aplicar la ciencia financiera y la teoría estadística a problemas empresariales reales?",
    "jawaban": "Actuario"
  },
  { "author" : "TURBO",
    "index": 180,
    "soal": " ¿La tradición de los novios pidiendo bendiciones a los padres de ambas partes?",
    "jawaban": "Sungkem"
  },
  { "author" : "TURBO",
    "index": 181,
    "soal": " ¿Qué tipo de salsa blanca hecha de aceite vegetal, huevos de gallina y vinagre?",
    "jawaban": "Mayonesa"
  },
  { "author" : "TURBO",
    "index": 182,
    "soal": " ¿Un término que significa no voto o actitud en una votación?",
    "jawaban": "abstenerse"
  },
  { "author" : "TURBO",
    "index": 183,
    "soal": " ¿Una de las flores nacionales de Indonesia tiene el apodo de puspa de la nación?",
    "jawaban": "Jazmín"
  },
  { "author" : "TURBO",
    "index": 184,
    "soal": " Un instrumento de cuerda que se toca punteando, ¿viene de Rote, NTT?",
    "jawaban": "Sasando"
  },
  { "author" : "TURBO",
    "index": 185,
    "soal": " ¿La roca que cuelga y gotea del techo de una cueva de piedra caliza?",
    "jawaban": "Estalactitas"
  },
  { "author" : "TURBO",
    "index": 186,
    "soal": " ¿El icono del estado de Singapur en forma de estatua con cabeza de león y cuerpo de pez?",
    "jawaban": "Merlion"
  },
  { "author" : "TURBO",
    "index": 187,
    "soal": " ¿El término en el ajedrez cuando la posición del rey no puede separarse del movimiento del oponente?",
    "jawaban": "Mate"
  },
  { "author" : "TURBO",
    "index": 188,
    "soal": " ¿Un instrumento para medir la presión del aire, utilizado en la predicción meteorológica?",
    "jawaban": "Barómetro"
  },
  { "author" : "TURBO",
    "index": 189,
    "soal": " ¿El 32º presidente de Estados Unidos, el único que ha sido elegido 4 veces?",
    "jawaban": "Roosevelt"
  },
  { "author" : "TURBO",
    "index": 190,
    "soal": " ¿Qué tipo de casa arquitectónica tradicional javanesa se construye a partir de cuatro pilares principales?",
    "jawaban": "Limasan"
  },
  { "author" : "TURBO",
    "index": 191,
    "soal": " ¿El término japonés para los caracteres de imágenes que se utilizan en los mensajes electrónicos?",
    "jawaban": "Emoji"
  },
  { "author" : "TURBO",
    "index": 192,
    "soal": " ¿Una de las típicas dagas indonesias cuyas hojas a menudo se enrollan?",
    "jawaban": "Kris"
  },
  { "author" : "TURBO",
    "index": 193,
    "soal": " ¿Un nativo del continente australiano caracterizado por piel oscura y cabello rizado?",
    "jawaban": "Aborigin"
  },
  { "author" : "TURBO",
    "index": 194,
    "soal": " T¿Un baile típico de la tribu Gayo de Aceh, realizado para celebrar un evento importante?",
    "jawaban": "Danza saman"
  },
  { "author" : "TURBO",
    "index": 195,
    "soal": " ¿La forma joven de insectos o anfibios cuyo desarrollo es por metamorfosis?",
    "jawaban": "Larva"
  },
  { "author" : "TURBO",
    "index": 196,
    "soal": " ¿Dónde está amarrado el barco en el puerto para la carga y descarga de mercancías?",
    "jawaban": "Muelle"
  },
  { "author" : "TURBO",
    "index": 197,
    "soal": " ¿Qué tipo de reloj funciona con un motor eléctrico o con pilas?",
    "jawaban": "Cuarzo"
  },
  { "author" : "TURBO",
    "index": 198,
    "soal": " ¿Tribus hindúes que viven alrededor de las montañas de Bromo y Semeru?",
    "jawaban": "perca"
  },
  { "author" : "TURBO",
    "index": 199,
    "soal": " ¿Un juguete que puede girar sobre un eje y estar en equilibrio en un punto?",
    "jawaban": "Cima"
  },
  { "author" : "TURBO",
    "index": 200,
    "soal": " ¿Qué legumbres son la principal fuente de proteína vegetal del mundo?",
    "jawaban": "Soja"
  },
  { "author" : "TURBO",
    "index": 201,
    "soal": " ¿Un líquido incoloro e inodoro utilizado como arma química de destrucción masiva?",
    "jawaban": "Sarin"
  },
  { "author" : "TURBO",
    "index": 202,
    "soal": " ¿La rama de la odontología que se especializa en la ciencia de enderezar los dientes?",
    "jawaban": "ortodoncia"
  },
  { "author" : "TURBO",
    "index": 203,
    "soal": " ¿Un término que viene del italiano, que significa bailarina de ballet?",
    "jawaban": "bailarina"
  },
  { "author" : "TURBO",
    "index": 204,
    "soal": " ¿Terrazas de arroz en Bali reconocidas por la UNESCO como Patrimonio Cultural de la Humanidad?",
    "jawaban": "Jatiluwih"
  },
  { "author" : "TURBO",
    "index": 205,
    "soal": " ¿Un alimento básico que sustituye al arroz elaborado con mandioca o mandioca?",
    "jawaban": "Tiwul"
  },
  { "author" : "TURBO",
    "index": 206,
    "soal": " ¿Qué parte del ojo convierte la luz en señales nerviosas?",
    "jawaban": "Retina"
  },
  { "author" : "TURBO",
    "index": 207,
    "soal": " ¿Cómo se llamaba la máquina de codificación utilizada por la Alemania nazi en la Segunda Guerra Mundial?",
    "jawaban": "Enigma"
  },
  { "author" : "TURBO",
    "index": 208,
    "soal": " ¿Cosméticos hechos de cera, pigmento, aceite, aplicados a los labios?",
    "jawaban": "Lápiz labial"
  },
  { "author" : "TURBO",
    "index": 209,
    "soal": " ¿Condimento alimenticio elaborado con soja fermentada, harina y sal?",
    "jawaban": "Taco"
  },
  { "author" : "TURBO",
    "index": 210,
    "soal": " ¿Microorganismos que pueden reducir la productividad de los animales que alimentan?",
    "jawaban": "Parásito"
  },
  { "author" : "TURBO",
    "index": 211,
    "soal": " ¿El dulce líquido que producen las flores para atraer a los polinizadores?",
    "jawaban": "Néctar"
  },
  { "author" : "TURBO",
    "index": 212,
    "soal": " ¿El proceso de hacer nuevas tierras a partir del lecho marino o del lecho de un río?",
    "jawaban": "Recuperación"
  },
  { "author" : "TURBO",
    "index": 213,
    "soal": " I¿Cuál es el término para el estado de intención antes de realizar el Hayy o la Umrah?",
    "jawaban": "Ihram"
  },
  { "author" : "TURBO",
    "index": 214,
    "soal": " Instrumento de cuerda típico de la tribu Banjar, que se toca con púas?",
    "jawaban": "urgente"
  },
  { "author" : "TURBO",
    "index": 215,
    "soal": " ¿La mortal enfermedad viral que asoló África occidental en 2014?",
    "jawaban": "Ebola"
  },
  { "author" : "TURBO",
    "index": 216,
    "soal": " ¿El tipo de hurón que se sabe que come granos de café enteros?",
    "jawaban": "Mangosta"
  },
  { "author" : "TURBO",
    "index": 217,
    "soal": " ¿El nombre de la espada que tenía el rey Arturo según la mitología británica?",
    "jawaban": "Excalibur"
  },
  { "author" : "TURBO",
    "index": 218,
    "soal": " ¿Un país que tiene una bandera roja y blanca como Indonesia?",
    "jawaban": "Mónaco"
  },
  { "author" : "TURBO",
    "index": 219,
    "soal": " ¿Una representación teatral con gestos silenciosos?",
    "jawaban": "Pantomima"
  },
  { "author" : "TURBO",
    "index": 220,
    "soal": " ¿La tradición nupcial de los novios no permite salir de casa?",
    "jawaban": "Reclusión"
  },
  { "author" : "TURBO",
    "index": 221,
    "soal": " ¿Qué tipo de animal está activo por la noche y duerme durante el día?",
    "jawaban": "Nocturno"
  },
  { "author" : "TURBO",
    "index": 222,
    "soal": " ¿Trastornos congénitos de la ausencia del pigmento melanina en los ojos, piel, cabello?",
    "jawaban": "Albinismo"
  },
  { "author" : "TURBO",
    "index": 223,
    "soal": " ¿La rama de la lingüística que estudia el origen de las palabras?",
    "jawaban": "Etimología"
  },
  { "author" : "TURBO",
    "index": 224,
    "soal": " Tipos de peces que pueden saltar a la orilla, que se encuentran en la isla de Borneo?",
    "jawaban": "Disparo"
  },
  { "author" : "TURBO",
    "index": 225,
    "soal": " ¿Una moneda electrónica con tecnología blockchain creada en 2009?",
    "jawaban": "Bitcoin"
  },
  { "author" : "TURBO",
    "index": 226,
    "soal": " ¿El mayor empresario de cigarrillos en 1918, propietario de una fábrica de kretek de tres pacas?",
    "jawaban": "Nitisemito"
  },
  { "author" : "TURBO",
    "index": 227,
    "soal": " ¿Este pintor expresionista es conocido como el maestro de la pintura indonesia?",
    "jawaban": "Affandi"
  }
]
